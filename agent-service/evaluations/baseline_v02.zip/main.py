import asyncio
import json
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Annotated, Any
from uuid import UUID

import httpx
from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, ConfigDict, Field
from redis.asyncio import Redis
from redis.exceptions import RedisError

from core.config import Settings, load_settings
from core.context import ToolContext
from core.engine import AgentEngine
from core.state import AgentError
from memory.redis_memory import RedisMemory
from models.llm_client import open_model
from tools.java_api import JavaAPI, ShopLinkError
from tools.shop_tools import search_shops


@dataclass
class ShopSearchResult:
    page: int
    data: list[dict[str, Any]]


class ChatRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    message: str = Field(min_length=1, max_length=4000)
    session_id: UUID | None = None


def create_app(*, transport: httpx.AsyncBaseTransport | None = None,
               model_transport: httpx.AsyncBaseTransport | None = None,
               memory=None, settings: Settings | None = None) -> FastAPI:
    def config():
        return settings or load_settings()

    @asynccontextmanager
    async def lifespan(app):
        current = config()
        async with httpx.AsyncClient(base_url=current.shoplink_base_url,
                                    timeout=httpx.Timeout(5, connect=2),
                                    transport=transport, trust_env=False) as client:
            redis = Redis.from_url(current.redis_url, decode_responses=True,
                                   socket_connect_timeout=2, socket_timeout=3)
            app.state.shoplink_client = client
            app.state.memory = memory or RedisMemory(redis)
            app.state.redis = redis
            yield
            await redis.aclose()

    app = FastAPI(title="ShopLink 多Agent服务", version="0.2.0", lifespan=lifespan)

    @app.exception_handler(AgentError)
    async def agent_error(_request, exc):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=exc.status_code,
                            content={"detail": {"code": exc.code, "message": str(exc)}})

    async def identity(request: Request, authorization: str | None):
        token = (authorization or "").strip()
        if token.lower().startswith("bearer "):
            token = token[7:].strip()
        api = JavaAPI(request.app.state.shoplink_client, token)
        if not token:
            return "guest", ToolContext(java=api, business_timezone=config().business_timezone)
        try:
            user = await api.get("/user/me", authenticated=True)
        except ShopLinkError as exc:
            raise AgentError(exc.code, str(exc), exc.status_code) from exc
        if not isinstance(user, dict) or not isinstance(user.get("id"), int):
            raise AgentError("LOGIN_REQUIRED", "登录状态已失效，请重新登录", 401)
        return "user:" + str(user["id"]), ToolContext(java=api, authenticated=True, business_timezone=config().business_timezone)

    async def prepare(body: ChatRequest, request: Request, authorization: str | None):
        current = config()
        if not current.configured:
            raise AgentError("MODEL_NOT_CONFIGURED",
                             "请在agent-service/.env填写OPENAI_API_KEY和OPENAI_MODEL", 503)
        if not body.message.strip():
            raise AgentError("EMPTY_MESSAGE", "请输入问题", 422)
        scope, ctx = await identity(request, authorization)
        return current, scope, ctx

    async def run(body, request, current, scope, ctx, emit):
        memory_store = request.app.state.memory
        try:
            async with asyncio.timeout(current.turn_timeout):
                async with memory_store.turn(scope, str(body.session_id) if body.session_id else None) as (session_id, history):
                    await emit({"type": "session", "session_id": session_id})
                    trace = []

                    async def record(event):
                        trace.append(event)
                        await emit(event)

                    async with open_model(current, model_transport) as model:
                        engine = AgentEngine(model, current.model, current.max_rounds)
                        answer = await engine.run(body.message.strip(), history, ctx, record)
                    # Only complete turns are committed. Token/Authorization never enter memory.
                    history.append({"user": body.message.strip(), "assistant": answer, "trace": trace})
                    await memory_store.save(scope, session_id, history)
                    result = {"session_id": session_id, "answer": answer, "trace": trace}
                    await emit({"type": "done", **result})
                    return result
        except TimeoutError as exc:
            raise AgentError("TURN_TIMEOUT", "本轮执行超时，请缩小问题范围", 504) from exc

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/agent/status")
    async def status(request: Request):
        current = config()
        try:
            await request.app.state.redis.ping()
            redis_ok = True
        except RedisError:
            redis_ok = False
        try:
            await JavaAPI(request.app.state.shoplink_client).get("/shop-type/list")
            java_ok = True
        except ShopLinkError:
            java_ok = False
        return {"configured": current.configured, "model": current.model,
                "base_url": current.base_url, "redis": redis_ok, "shoplink": java_ok,
                "ready": current.configured and redis_ok and java_ok,
                "agents": ["coordinator", "shop", "voucher", "order"]}

    @app.post("/agent/chat")
    async def chat(body: ChatRequest, request: Request, authorization: str | None = Header(default=None)):
        current, scope, ctx = await prepare(body, request, authorization)
        async def ignore(_event):
            pass
        return await run(body, request, current, scope, ctx, ignore)

    @app.post("/agent/chat/stream")
    async def stream(body: ChatRequest, request: Request, authorization: str | None = Header(default=None)):
        current, scope, ctx = await prepare(body, request, authorization)

        async def events():
            queue = asyncio.Queue()
            async def produce():
                try:
                    await run(body, request, current, scope, ctx, queue.put)
                except AgentError as exc:
                    await queue.put({"type": "error", "code": exc.code, "message": str(exc)})
                except Exception:
                    # Upstream responses may contain sensitive provider details.
                    import logging
                    logging.getLogger(__name__).error("Agent turn failed; unexpected error")
                    await queue.put({"type": "error", "code": "INTERNAL_ERROR", "message": "服务内部错误，请检查服务配置或稍后重试"})
                finally:
                    await queue.put(None)
            task = asyncio.create_task(produce())
            try:
                while True:
                    try:
                        event = await asyncio.wait_for(queue.get(), timeout=10)
                    except TimeoutError:
                        yield ": keep-alive\n\n"
                        continue
                    if event is None:
                        break
                    yield "data: " + json.dumps(event, ensure_ascii=False, default=str) + "\n\n"
            finally:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        return StreamingResponse(events(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    @app.get("/agent/conversations/{session_id}")
    async def conversation(session_id: UUID, request: Request, authorization: str | None = Header(default=None)):
        scope, _ctx = await identity(request, authorization)
        return {"session_id": str(session_id),
                "turns": await request.app.state.memory.load(scope, str(session_id))}

    @app.get("/tools/shops/search", response_model=ShopSearchResult)
    async def shops(request: Request, keyword: Annotated[str, Query(max_length=128)] = "",
                    page: Annotated[int, Query(ge=1, le=2147483647)] = 1):
        try:
            data = await search_shops(request.app.state.shoplink_client, keyword, page)
            return ShopSearchResult(page=page, data=data)
        except ShopLinkError as exc:
            raise HTTPException(exc.status_code, detail={"code": exc.code, "message": str(exc)}) from exc

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8090)


