"""Business tools backed by ShopLink's Java API."""
