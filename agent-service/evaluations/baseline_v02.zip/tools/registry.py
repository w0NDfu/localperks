import inspect
import json
from dataclasses import dataclass
from typing import get_type_hints

from pydantic import BaseModel, ConfigDict, ValidationError, create_model

from core.context import ToolContext
from tools.java_api import ShopLinkError


@dataclass
class RegisteredTool:
    name: str
    agent: str
    description: str
    parameters: type[BaseModel]
    function: object

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters.model_json_schema(),
        }}


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, RegisteredTool] = {}

    def tool(self, *, agent: str, description: str):
        def register(function):
            if function.__name__ in self._tools:
                raise ValueError("Duplicate tool registration")
            hints = get_type_hints(function, include_extras=True)
            fields = {}
            for name, parameter in inspect.signature(function).parameters.items():
                if name == "ctx":
                    continue
                default = ... if parameter.default is inspect.Parameter.empty else parameter.default
                fields[name] = (hints[name], default)
            model = create_model(
                function.__name__ + "Arguments",
                __config__=ConfigDict(extra="forbid", strict=True),
                **fields,
            )
            self._tools[function.__name__] = RegisteredTool(
                function.__name__, agent, description, model, function
            )
            return function
        return register

    def schemas(self, agent: str) -> list[dict]:
        return [tool.schema() for tool in self._tools.values() if tool.agent == agent]

    async def execute(self, agent: str, name: str, arguments: str, ctx: ToolContext) -> dict:
        tool = self._tools.get(name)
        if tool is None or tool.agent != agent:
            return {"error": {"code": "UNKNOWN_TOOL", "message": "工具不在当前 Agent 的权限范围"}}
        try:
            values = tool.parameters.model_validate(json.loads(arguments))
        except (ValueError, TypeError, ValidationError):
            return {"error": {"code": "INVALID_ARGUMENTS", "message": "工具参数不符合定义，请按工具schema修正"}}
        try:
            return await tool.function(ctx, **values.model_dump())
        except ShopLinkError as exc:
            return {"error": {"code": exc.code, "message": str(exc)}}


registry = ToolRegistry()

