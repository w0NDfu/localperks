import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import dotenv_values

PROJECT_ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Settings:
    api_key: str = field(repr=False)
    model: str = ""
    base_url: str = "https://api.openlux.ai/v1"
    shoplink_base_url: str = "http://127.0.0.1:8081"
    redis_url: str = field(default="redis://127.0.0.1:6379/0", repr=False)
    business_timezone: str = "Asia/Shanghai"
    max_rounds: int = 5
    turn_timeout: int = 100

    @property
    def configured(self) -> bool:
        return bool(self.api_key and self.model)


def load_settings() -> Settings:
    local = dotenv_values(PROJECT_ROOT / ".env")

    def value(name: str, default: str = "") -> str:
        return (os.environ.get(name, local.get(name)) or default).strip()

    return Settings(
        api_key=value("OPENAI_API_KEY"),
        model=value("OPENAI_MODEL"),
        base_url=value("OPENAI_BASE_URL", "https://api.openlux.ai/v1"),
        shoplink_base_url=value("SHOPLINK_BASE_URL", "http://127.0.0.1:8081"),
        redis_url=value("REDIS_URL", "redis://127.0.0.1:6379/0"),
        business_timezone=value("SHOPLINK_TIMEZONE", "Asia/Shanghai"),
    )

