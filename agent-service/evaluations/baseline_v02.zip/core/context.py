from dataclasses import dataclass, field

from tools.java_api import JavaAPI


@dataclass
class ToolContext:
    java: JavaAPI = field(repr=False)
    authenticated: bool = False
    business_timezone: str = "Asia/Shanghai"
    requests: list[dict] = field(default_factory=list)

