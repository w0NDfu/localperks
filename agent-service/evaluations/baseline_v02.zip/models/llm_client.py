from contextlib import asynccontextmanager

import httpx
from openai import AsyncOpenAI

from core.config import Settings


@asynccontextmanager
async def open_model(settings: Settings, transport: httpx.AsyncBaseTransport | None = None):
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(35, connect=8),
        transport=transport,
        trust_env=False,
    ) as http_client:
        async with AsyncOpenAI(
            api_key=settings.api_key,
            base_url=settings.base_url,
            max_retries=0,
            http_client=http_client,
        ) as client:
            yield client

